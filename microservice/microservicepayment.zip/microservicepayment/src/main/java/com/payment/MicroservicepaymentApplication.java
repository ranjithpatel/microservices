package com.payment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicepaymentApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicepaymentApplication.class, args);
	}

}
